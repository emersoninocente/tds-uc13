require('dotenv').config();
'use strict';

module.exports = {
  "username": process.env.USERNAMEDB,
  "password": process.env.PASSWORDDB,
  "database": process.env.NAMEDB,
  "host": process.env.HOSTDB,
  "port": process.env.PORTDB,
  "dialect": process.env.DIALECTDB,
  define: {
    "timestamp": true,
    "underscored": false,
    "underscoredAll": false
  }
}