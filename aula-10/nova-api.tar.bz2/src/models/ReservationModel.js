import Sequelize, { Model } from 'sequelize';

class ReservationModel extends Model {
}

export default ReservationModel;