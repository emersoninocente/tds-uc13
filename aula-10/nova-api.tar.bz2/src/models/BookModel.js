import Sequelize, { Model } from 'sequelize';

class BookModel extends Model {
}

export default BookModel;