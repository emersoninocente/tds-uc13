import Sequelize, { Model } from 'sequelize';

class GenreModel extends Model {
}

export default GenreModel;