import Sequelize, { Model } from "sequelize";

class User extends Model {
  static init(sequelize) {
    super.init({
        name: {
          type: Sequelize.STRING,
          allowNull: false,
        },
        email: {
          type: Sequelize.STRING,
          allowNull: false,
          unique: true,
          key: true,
        },
        phone: {
          type: Sequelize.STRING,
          allowNull: false,
          key: true,
        },
        birthday: {
          type: Sequelize.DATE,
          allowNull: true,
        },
        nationality: {
          type: Sequelize.STRING,
          allowNull: true,
        },
        isAdmin: {
          type: Sequelize.BOOLEAN,
          defaultValue: false,
        },
        isAuthor: {
          type: Sequelize.BOOLEAN,
          defaultValue: false,
        },
        status: {
          type: Sequelize.ENUM('active', 'inactive', 'banned'),
          defaultValue: 'active',
        },
        passwordHash: {
          type: Sequelize.STRING,
          allowNull: false,
        },
      }, {
        sequelize,
        tableName: 'users',
      });
  }
  
  static associate(models) {
    this.hasMany(models.Reservation, { foreignKey: 'userId', as: 'reservations' });
    this.hasMany(models.Book, { foreignKey: 'authorId', as: 'books' });
  }
}

export default User;