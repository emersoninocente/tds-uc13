import User from '../models/UserModel.js'

class UsersController {
    async index (req, res) {
        //const users = {message:'Listagem de todos os usuários'};
        return res.json(users);
    }

    async show (req, res){
        try {
            //const users = {message:'Dados do usuário ID: ' + req.params.id};
            const users = '';
            if (!users) {
                return res.status(404).json({error:'User not found'});
            }
            return res.json(users);
        } catch(error) {
            return res.status(500).json({error:'Failed to retrieve user'});
        }
    }

    async create (req, res){
        try {
            const users = {message:'Criando usuário'};
            //const users = '';
            if (!users) {
                return res.status(404).json({error:'User not found'});
            }
            return res.status(201).json(users);
        } catch(error) {
            return res.status(500).json({error:'Failed to retrieve user'});
        }
    }

    async update (req, res){
        try {
            const users = {message:'Atualizados os dados do usuário ID: ' + req.params.id};
            //const users = '';
            if (!users) {
                return res.status(404).json({error:'User not found'});
            }
            return res.json(users);
        } catch(error) {
            return res.status(500).json({error:'Failed to retrieve user'});
        }
    }

    async delete (req, res){
        try {
            const users = {message:'Dados do usuário ID: ' + req.params.id};
            //const users = '';
            if (!users) {
                return res.status(404).json({error:'User not found'});
            }
            return res.status(204).json();
        } catch(error) {
            return res.status(500).json({error:'Failed to retrieve user'});
        }
    }
}

export default new UsersController();