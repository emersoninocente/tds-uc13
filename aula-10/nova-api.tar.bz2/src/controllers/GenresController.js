import Genres from '../models/GenreModel';

class GenresController {
}

export default new GenresController();