import Reservations from '../controllers/BooksController.js'

class ReservationsController {
}

export default new ReservationsController();