import Books from '../models/BookModel.js'

class BooksController {
    async index (req, res) {
    }

    async show (req, res) {
    }

    async create (req, res) {
    }

    async update (req, res) {
    }

    async delete (req, res) {
    }

}

export default new BooksController();