import Genres from '../models/GenreModel';

class GenresController {
    async index (req, res) {
    }

    async show (req, res) {
    }

    async create (req, res) {
    }

    async update (req, res) {
    }

    async delete (req, res) {
    }
}

export default new GenresController();