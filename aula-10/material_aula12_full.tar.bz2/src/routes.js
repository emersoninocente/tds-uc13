import { Router } from 'express';
import users from './controllers/UsersController.js';
import books from './controllers/BooksController.js';


const routes = new Router();

routes.get('/', (req, res) => {
  res.json({ message: 'Welcome to the Library API! SELECT YOUR CLASS/METHOD.' });
});

// Usuários
// Listar todos os usuários
routes.get('/users', users.index);
// Listar um usuário
routes.get('/users/:id', users.show);
// Criar um usuário
routes.post('/users', users.create);
// Editar um usuário
routes.put('/users/:id', users.update);
// Deletar um usuário
routes.delete('/users/:id', users.delete);

// Livros
// Listar todos os livros
routes.get('/books', books.index);
// Listar um livro
routes.get('/books/:id', books.show);
// Criar um livro
routes.post('/books', books.create);
// Editar um livro
routes.put('/books/:id', books.update);
// Deletar um livro
routes.delete('/books/:id', books.delete);

// Reservas
routes.get('/reservations', (req, res) => {
    res.json({ message: 'Você entrou na listagem de todas as reservas de livros!'})
});
routes.get('/reservations/:id', (req, res) => {
    res.json({ message: 'Você entrou na reserva ID: '+ req.params.id })
});
routes.post('/reservations', (req, res) => {
    res.json({ message: 'Você está criando uma reserva.'})
});
routes.put('/reservations/:id', (req, res) => {
    res.json({ message: `Você esta editado a reserva ID: ${req.params.id}`})
});
routes.delete('/reservations/:id', (req, res) => {
    res.json({ message: `Você deletou a reserva ID: $(req.params.id).`})
});

// Generos
routes.get('/genres', (req, res) => {
    res.json({ message: 'Você entrou na listagem de todos os gêneros de livros!'})
});
routes.get('/genres/:id', (req, res) => {
    res.json({ message: 'Você entrou na listadem do gênero ID: '+ req.params.id })
});
routes.post('/genres', (req, res) => {
    res.json({ message: 'Você está criando um gênero.'})
});
routes.put('/genres/:id', (req, res) => {
    res.json({ message: `Você esta editado o gênero ID: ${req.params.id}`})
});
routes.delete('/genres/:id', (req, res) => {
    res.json({ message: `Você deletou o gênero ID: $(req.params.id).`})
});
export default routes;