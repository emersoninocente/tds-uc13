import { Op } from 'sequelize';
import Reservations from '../models/ReservationModel.js';

class ReservationsController {
    async index (req, res) {
        try {
          console.log('Alerta: GET :: RESERVATION.index');
          const { query } = req;
          let where = {};
          let order = [];
          if (query.userId) {
            where = {
              ...where, userId: query.userId
            };
          }
          if (query.bookId) {
            where = {
              ...where, bookId: query.bookId
            };
          }
          if (query.comments) {
            where = {
              ...where, status: { [Op.like]: `%${query.comments}%` }
            };
          }
          if (query.order) {
            const orderFields = query.order.split(',');
            order = orderFields.map(field => {
                const direction = field.startsWith('-') ? 'DESC' : 'ASC';
                return [field.replace('-', ''), direction];
            });
          }
          const reserv = await Reservations.findAll({
            where,
            order
          });
          if (!reserv || reserv.length === 0) {
            return res.status(404).json({ error: 'No reservations found'});
          }
          return res.json(reserv);
        } catch(err) {
            console.log('Erro: GET :: RESERVATION.index', err)
            return res.status(500).json({error: 'Falha ao executar o processo.'});
        }
    }

    async show (req, res){
        try {
            console.log('Alerta: GET :: RESERVATION.show', req.params.id);
            const reserv = await Reservations.findOne({
                where: { id: req.params.id }
            });
            if (!reserv) {
                return res.status(404).json({error:'Reservation not found'});
            }
            return res.json(reserv);
        } catch(err) {
            console.log('Erro: GET :: RESERVATION.show', err);
            return res.status(500).json({error:'Failed to retrieve reservation'});
        }
    }

    async create (req, res){
        try {
            console.log('Alerta: POST :: RESERVATION.create');
            const reserv = await Reservations.create(req.body);
            if (!reserv) {
                return res.status(404).json({error:'Reservation not found'});
            }
            return res.status(201).json(reserv);
        } catch(err) {
            console.log('Erro POST :: RESERVATION.create', err);
            return res.status(500).json({error:'Failed to retrieve reservation'});
        }
    }

    async update(req, res) {
      try {
        const [updated] = await Reservations.update(req.body, {
          where: { id: req.params.id },
        });
        if (!updated) {
          return res.status(404).json({ error: 'Reservation not found' });
        }
        const updatedRes = await Reservations.findOne({ where: { id: req.params.id } });
        return res.json(updatedRes);
      } catch(err) {
        console.log("Erro: PUT :: RESERVATION.update", err)
        return res.status(400).json({ error: 'Failed to update reservation' });
      }
    }

    async delete (req, res){
        try {
            console.log('Alerta: DELETE :: RESERVATION.delete', req.params.id);
            const users = await Reservations.destroy({
                where: { id: req.params.id }
            });
            if (!users) {
                return res.status(404).json({error:'Reservation not found'});
            }
            return res.status(204).send();
        } catch(err) {
            console.log("Erro: DELETE :: RESERVATION.delete", err)
            return res.status(500).json({error:'Failed to retrieve reservation'});
        }
    }
}

export default new ReservationsController();