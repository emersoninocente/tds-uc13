import User from '../models/UserModel.js'
import { Op } from 'sequelize';

class UsersController {
    async index(req, res) {
        try {
            console.log('Alerta: GET :: USERS.index');
            let where = {};
            let order = [];
            if (req.query.name) {
                where = {
                    ...where, name: { [Op.like]: req.query.name }
                }
            }
            if (req.query.email) {
                where = {
                    ...where, email: { [Op.like]: req.query.email }
                }
            }
            if (req.query.status) {
                where = {
                    ...where, status: { [Op.in]: req.query.status.split(",") }
                }
            }
            if (req.query.order) {
                const orderFields = req.query.order.split(',');
                order = orderFields.map(field => {
                    const direction = field.startsWith('-') ? 'DESC' : 'ASC';
                    return [field.replace('-', ''), direction];
                });
            }
            const users = await User.findAll({
                where,
                order,
                attributes: { exclude: ['password'] }
            });
            if (!users || users.length === 0) {
                return res.status(404).json({ error: 'No users found' });
            }
            return res.json(users);
        } catch (err) {
            console.log('Erro: GET :: USERS', err)
            return res.status(500).json({ error: 'Falha ao executar o processo.' });
        }
    }

    async show(req, res) {
        try {
            console.log('Alerta: GET :: USERS.show', req.params.id);
            const users = await User.findOne({
                where: { id: req.params.id },
                attributes: ['name', 'email', 'birthday', 'nationality', 'isAuthor'],
            });
            if (!users) {
                return res.status(404).json({ error: 'User not found' });
            }
            return res.json(users);
        } catch (err) {
            console.log('Erro: GET :: USERS.show', err);
            return res.status(500).json({ error: 'Failed to retrieve user' });
        }
    }

    async create(req, res) {
        try {
            console.log('Alerta: POST :: USERS.create');
            const user = await User.create(req.body);
            if (!user) {
                return res.status(404).json({ error: 'User not found' });
            }
            return res.status(201).json(user);
        } catch (err) {
            console.log('Erro POST :: USERS.create', err);
            return res.status(500).json({ error: 'Failed to retrieve user' });
        }
    }

    async update(req, res) {
        try {
            const [updated] = await User.update(req.body, {
                where: { id: req.params.id },
                attributes: { exclude: ['password'] }
            });
            if (!updated) {
                return res.status(404).json({ error: 'User not found' });
            }
            const updatedUser = await User.findOne({
                where: { id: req.params.id },
                attributes: { exclude: ['password'] }
            });
            return res.json(updatedUser);
        } catch (err) {
            console.log("Erro: GET :: USERS.update", err)
            return res.status(400).json({ error: 'Failed to update user' });
        }
    }

    async delete(req, res) {
        try {
            console.log('Alerta: DELETE :: USER.delete', req.params.id);
            const users = await User.destroy({
                where: { id: req.params.id }
            });
            if (!users) {
                return res.status(404).json({ error: 'User not found' });
            }
            return res.status(204).send();
        } catch (err) {
            console.log("Erro: DELETE :: USERS.delete", err)
            return res.status(500).json({ error: 'Failed to retrieve user' });
        }
    }
}

export default new UsersController();