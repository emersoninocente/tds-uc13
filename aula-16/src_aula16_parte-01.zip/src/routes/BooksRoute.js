import { Router } from 'express';
import books from '../controllers/BooksController.js';

const routes = new Router();

// Livros
// Listar todos os livros
routes.get('/', books.index);
// Listar um livro
routes.get('/:id', books.show);
// Criar um livro
routes.post('/', books.create);
// Editar um livro
routes.put('/:id', books.update);
// Deletar um livro
routes.delete('/:id', books.delete);

export default routes;