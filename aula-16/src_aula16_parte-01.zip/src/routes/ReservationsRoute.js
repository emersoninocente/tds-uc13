import reservations from '../controllers/ReservationsController.js';
import { Router } from 'express';

const routes = new Router();

// Reservas
routes.get('/', reservations.index);
routes.get('/:id', reservations.show);
routes.post('/', reservations.create);
routes.put('/:id', reservations.update);
routes.delete('/:id', reservations.delete);

export default routes;