import { Router } from 'express';
import genres from '../controllers/GenresController.js';

const routes = new Router();

// Generos
routes.get('/', genres.index);
routes.get('/:id', genres.show);
routes.post('/', genres.create);
routes.put('/:id', genres.update);
routes.delete('/:id', genres.delete);

export default routes;