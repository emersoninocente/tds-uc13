import { Router } from 'express';
import UserMiddleware from '../middleware/UsersMiddleware.js';
import users from '../controllers/UsersController.js';

const routes = new Router();

// Usuários
// Listar todos os usuários
routes.get('/', users.index);
// Listar um usuário
routes.get('/:id', users.show);
// Criar um usuário
routes.post('/', UserMiddleware.checkUserCreate, users.create);
// Editar um usuário
routes.put('/:id', users.update);
// Deletar um usuário
routes.delete('/:id', users.delete);

export default routes;