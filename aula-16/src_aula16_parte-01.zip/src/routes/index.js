import { Router } from 'express';
import users from './UsersRoute.js';
import books from './BooksRoute.js';
import genres from './GenresRoute.js';
import reservations from './ReservationsRoute.js';

const routes = new Router();

// Middleware global
routes.use((req, res, next) => {
  console.log(`Requisição recebida: ${req.method} ${req.url}`);
  next(); // Passa para o próximo middleware ou rota
});

routes.use('/users', users);
routes.use('/books', books);
routes.use('/genres', genres);
routes.use('/reservations', reservations);

routes.get('/', (req, res) => {
  res.json({ message: 'Welcome to the Library API! SELECT YOUR CLASS/METHOD.' });
});

export default routes;