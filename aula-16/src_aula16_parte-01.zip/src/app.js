import express from 'express';
import { configDotenv } from 'dotenv';
import routes from './routes/index.js';
// Importa as configuracoes para BD
import './database/index.js';

configDotenv();

class App {
  constructor() {
    this.server = express();
    this.middlewares();
    this.routes();
  }

  middlewares() {
    this.server.use(express.json());
  }

  routes() {
    this.server.use(routes);
  }
}

export default new App().server;