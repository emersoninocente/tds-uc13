import express from 'express';
import { configDotenv } from 'dotenv';
import routes from './routes/index.js';
// Importa as configuracoes para BD
import './database/index.js';
// Import do Swagger para documentacao
import swaggerUI from 'swagger-ui-express';
import YAML from 'yamljs';

configDotenv();

class App {
  constructor() {
    this.server = express();
    this.middlewares();
    this.routes();
    this.swaggerYAML();
  }

  middlewares() {
    this.server.use(express.json());
  }

  routes() {
    this.server.use(routes);
  }

  swaggerYAML() {
    const swaggerDocument = YAML.load('./src/swagger.yaml');
    this.server.use('/api-docs', swaggerUI.serve, swaggerUI.setup(swaggerDocument));
  }
}

export default new App().server;