import Sequelize from 'sequelize';
import config from '../config/database.cjs';
import Book from '../models/BookModel.js';
import Reservation from '../models/ReservationModel.js';
import User from '../models/UserModel.js';
import Genre from '../models/GenreModel.js';

const models = [Book, Reservation, User, Genre];
class Database {
    constructor() {
        try {
          this.connection = new Sequelize(config);
          this.testConnection();
          this.init();
          this.sync();
        } catch (error) {
          console.error('Database connection error: ', error);
        }
    }

    init() {
        models.forEach(model => {
            model.init(this.connection);
        });
        models.forEach(model => {
            if (typeof model.associate === 'function') {
                model.associate(this.connection.models);
            }
        });
    }

    testConnection() {
        this.connection.authenticate()
            .then(() => {
                console.log('Database connection has been established successfully.');
            })
            .catch(err => {
                console.error('Unable to connect to the database:', err);
            });
    }

    sync() {
        this.connection.sync({ force: false })
            .then(() => {
                console.log('Database synchronized successfully.');
            })
            .catch(err => {
                console.error('Error synchronizing the database:', err);
            });
    }
}

export default new Database();