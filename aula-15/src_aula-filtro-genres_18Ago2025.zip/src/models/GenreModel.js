import Sequelize, { Model } from 'sequelize';

class GenreModel extends Model {
    static init(sequelize) {
        super.init({
            name:{
                type: Sequelize.STRING,
                allowNull: false,
            }
        },{
            sequelize,
            tableName: 'genres',
            timestamps: false
        })
    }

    static associate(models){
        this.hasMany(models.BookModel, {foreignKey: 'genreId', as: 'books'})
    }
}

export default GenreModel;