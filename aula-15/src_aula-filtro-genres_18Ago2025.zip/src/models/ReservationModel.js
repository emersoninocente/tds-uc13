import Sequelize, { Model } from 'sequelize';

class ReservationModel extends Model {
    static init(sequelize) {
        super.init({
            bookId:{
                type: Sequelize.INTEGER,
                allowNull: false,
                references: {
                    model: 'books',
                    key: 'id'
                },
                onDelete: 'NO ACTION',
                onUpdate: 'NO ACTION'
            },
            userId: {
                type: Sequelize.INTEGER,
                allowNull: false,
                references: {
                    model: 'users',
                    key: 'id'
                },
                onDelete: 'NO ACTION',
                onUpdate: 'NO ACTION'
            },
            date: {
                type: Sequelize.DATE,
                allowNull: false
            },
            comments: {
                type: Sequelize.STRING,
                allowNull: true
            }
        },{
            sequelize,
            tableName: 'reservations',
            timestamps: false
        })
    }

    static associate(models){
        this.belongsTo(models.BookModel, {foreignKey: 'bookId', as: 'books'});
        this.belongsTo(models.UserModel, {foreignKey: 'UserId', as: 'users'});
    }
}

export default ReservationModel;