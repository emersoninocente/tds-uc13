import Sequelize, { Model } from 'sequelize';

class BookModel extends Model {
    static init(sequelize) {
        super.init({
            title: {
                type: Sequelize.STRING,
                allowNull: false,
            },
            isbn: {
                type: Sequelize.STRING,
                allowNull: false,
                unique: true,
                key: true,
            },
            genreId: {
                type: Sequelize.INTEGER,
                allowNull: false,
                references: {
                    model: 'genres',
                    key:'id',
                },
                onUpdate: 'NO ACTION',
                onDelete: 'NO ACTION',
            },
            authorId: {
                type: Sequelize.INTEGER,
                allowNull: false,
                references: {
                    model: 'users',
                    key: 'id',
                },
                onUpdate: 'NO ACTION',
                onDelete: 'NO ACTION',
            }
        },{
            sequelize,
            tableName: 'books',
            timestamps: false
        })
    }

    static associate(models) {
        this.belongsTo(models.GenreModel, { foreignKey: 'genreId', as: 'genre' });
        this.belongsTo(models.UserModel, {foreignKey: 'authorId', as: 'author'}); //
        this.hasMany(models.ReservationModel, {foreignKey: 'bookId', as: 'book'});
    }
}

export default BookModel;