import User from '../models/UserModel.js'
// Precisamos importar os operadores do sequelize
// para que possamos aplicar os filtros na query
// do banco de dados
import { Op } from 'sequelize';

class UsersController {
    async index(req, res) {
        try {
            console.log('Alerta: GET :: USERS.index');
            const users = await User.findAll({
                attributes: { exclude: ['password'] }
            });
            return res.json(users);
        } catch (err) {
            console.log('Erro: GET :: USERS', err)
            return res.status(500).json({ error: 'Falha ao executar o processo.' });
        }
    }
    // Parâmetros de filtro precisam estar no corpo em formato json
    async index2(req, res) {
        try {
            console.log('Alerta: GET :: USERS.index2');
            const { name, email, status, sort } = req.body;

            // Criar uma variavel para receber os filtros
            let where = {};
            // Testar os campos dos filtros e carregar na where
            if (name) {
                where = {
                    ...where, name: { [Op.like]: name }
                }
            }
            if (email) {
                where = {
                    ...where, email: { [Op.like]: email }
                }
            }
            if (status) {
                where = {
                    ...where, status: { [Op.in]: status.split(",") }
                }
            }
            // SQL: where name like = 'João%' and status = ['active','banned']


            // Devemos carregar nossa query com os dados dos filtros
            const users = await User.findAll({
                where,
                attributes: { exclude: ['password'] }
            });
            return res.json(users);
        } catch (err) {
            console.log('Erro: GET :: USERS', err)
            return res.status(500).json({ error: 'Falha ao executar o processo.' });
        }
    }

    async show(req, res) {
        try {
            console.log('Alerta: GET :: USERS.show', req.params.id);
            const users = await User.findOne({
                where: { id: req.params.id },
                attributes: ['name', 'email', 'birthday', 'nationality', 'isAuthor'],
            });
            if (!users) {
                return res.status(404).json({ error: 'User not found' });
            }
            return res.json(users);
        } catch (err) {
            console.log('Erro: GET :: USERS.show', err);
            return res.status(500).json({ error: 'Failed to retrieve user' });
        }
    }

    async create(req, res) {
        try {
            console.log('Alerta: POST :: USERS.create');
            const user = await User.create(req.body);
            if (!user) {
                return res.status(404).json({ error: 'User not found' });
            }
            return res.status(201).json(user);
        } catch (err) {
            console.log('Erro POST :: USERS.create', err);
            return res.status(500).json({ error: 'Failed to retrieve user' });
        }
    }

    async update(req, res) {
        try {
            const [updated] = await User.update(req.body, {
                where: { id: req.params.id },
                attributes: { exclude: ['password'] }
            });
            if (!updated) {
                return res.status(404).json({ error: 'User not found' });
            }
            const updatedUser = await User.findOne({ where: { id: req.params.id } });
            return res.json(updatedUser);
        } catch (err) {
            console.log("Erro: GET :: USERS.update", err)
            return res.status(400).json({ error: 'Failed to update user' });
        }
    }

    async delete(req, res) {
        try {
            console.log('Alerta: DELETE :: USER.delete', req.params.id);
            const users = await User.destroy({
                where: { id: req.params.id }
            });
            if (!users) {
                return res.status(404).json({ error: 'User not found' });
            }
            return res.status(204).send();
        } catch (err) {
            console.log("Erro: DELETE :: USERS.delete", err)
            return res.status(500).json({ error: 'Failed to retrieve user' });
        }
    }
}

export default new UsersController();