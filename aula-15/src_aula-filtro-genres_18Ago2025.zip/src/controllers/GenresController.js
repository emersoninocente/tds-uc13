import Genres from '../models/GenreModel.js';
import { Op } from 'sequelize';

class GenresController {
    // http://servidor:porta/genres?name=Fic%
    async index(req, res) {
        try {
            console.log('Alerta: GET :: GENRES.index');
            // Variavel deve ser definida como objeto
            const { query } = req;
            if (query && Object.keys(query).length > 0) {
                console.log('Mensagem: GET :: Genres.Index Query');
                const registrosGeneros = await Genres.findAll({
                    where: {
                        [Op.or]: [
                            { name: { [Op.like]: `%${query.name}%` } }
                        ]
                    }
                });
                return res.json(registrosGeneros);
            } else {
                const registrosGeneros = await Genres.findAll();
                return res.json(registrosGeneros);
            };
        } catch (err) {
            console.log('Erro: GET :: GENRES.index', err)
            return res.status(500).json({ error: 'Falha ao executar o processo.' });
        }
    }

    async show(req, res) {
        try {
            console.log('Alerta: GET :: GENRES.show', req.params.id);
            const registrosGeneros = await Genres.findOne({
                where: { id: req.params.id },
            });
            if (!registrosGeneros) {
                return res.status(404).json({ error: 'Genre not found' });
            }
            return res.json(registrosGeneros);
        } catch (err) {
            console.log('Erro: GET :: GENRES.show', err);
            return res.status(500).json({ error: 'Failed to retrieve Genre' });
        }
    }

    async create(req, res) {
        try {
            const registrosGeneros = await Genres.create(req.body);
            if (!registrosGeneros) {
                return res.status(404).json({ error: 'Genre not created' });
            }
            return res.status(201).json(registrosGeneros);
        } catch (err) {
            console.log('Erro: POST :: GENRES.create', err);
            return res.status(500).json({ error: 'Falha ao executar o processo.' })
        }
    }

    async update(req, res) {
        try {
            const [updated] = await Genres.update(req.body, {
                where: { id: req.params.id },
            });
            if (!updated) {
                return res.status(404).json({ error: 'Genre not found' });
            }
            const updatedGenre = await Genres.findOne({ where: { id: req.params.id } });
            return res.json(updatedGenre);
        } catch (err) {
            console.log("Erro: PUT :: GENRE.update", err)
            return res.status(400).json({ error: 'Failed to update genre' });
        }
    }

    async delete(req, res) {
        try {
            console.log('Alerta: DELETE :: GENRE.delete', req.params.id);
            const registrosGeneros = await Genres.destroy({
                where: { id: req.params.id }
            });
            if (!registrosGeneros) {
                return res.status(404).json({ error: 'Genre not found' });
            }
            return res.status(204).send();
        } catch (err) {
            console.log("Erro: DELETE :: USERS.delete", err)
            return res.status(500).json({ error: 'Failed to retrieve genre' });
        }
    }
}

export default new GenresController();