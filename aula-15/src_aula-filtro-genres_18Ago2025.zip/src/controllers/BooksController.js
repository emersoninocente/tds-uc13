import Books from '../models/BookModel.js'

class BooksController {
    async index (req, res) {
        try {
            const registrosLivros = await Books.findAll();
            if(!registrosLivros){
                return res.status(404).json({error: 'Books not found'})
            }
            return res.json(registrosLivros);
        }
        catch(err) {
            console.log('Erro: GET :: BOOKS.index', err)
            return res.status(500).json({error: 'Falha ao executar o processo.'})
        }
    }

    async show (req, res) {
        try{
            const registrosLivros = await Books.findOne({
                where: { id: req.params.id }
            })
            if(!registrosLivros){
                return res.status(404).json({error: 'Book not found'});
            }
            return res.status(200).json(registrosLivros);
        } catch(err){
            console.log('Erro: GET :: BOOKS.show',err);
            return res.status(500).json({error: 'Falha ao executar o processo.'})
        }
    }

    async create (req, res) {
        try{
            const registrosLivros = await Books.create(req.body);
            if(!registrosLivros){
                return res.status(404).json({error: 'User not created'});
            }
            return res.status(201).json(registrosLivros);
        } catch(err){
            console.log('Erro: POST :: BOOKS.create',err);
            return res.status(500).json({error: 'Falha ao executar o processo.'})
        }
    }

    async update (req, res) {
        try{
            const [registrosLivros] = await Books.update(req.body, {
                where: { id: req.params.id }});
            if(!registrosLivros){
                return res.status(400).json({error: 'Book not found'});
            }
            const updatedregistry = await Books.findOne({
                where: { id: req.params.id }
            })
            return res.json(updatedregistry);
        } catch(err){
            console.log('Erro: PUT :: BOOKS.update',err);
            return res.status(500).json({error: 'Falha ao executar o processo.'})
        }
    }

    async delete (req, res) {
        try{
            const registrosLivros = await Books.destroy({
                where: { id: req.params.id }
            });
            if(!registrosLivros){
                return res.status(404).json({error: 'User not found'});
            }
            return res.status(204).send();
        } catch(err){
            console.log('Erro: DELETE :: BOOKS.delete',err);
            return res.status(500).json({error: 'Falha ao executar o processo.'})
        }
    }

}

export default new BooksController();