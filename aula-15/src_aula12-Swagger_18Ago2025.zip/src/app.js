import express from 'express';
import { configDotenv } from 'dotenv';
import routes from './routes.js';
// Importa as configuracoes para BD
import './database/index.js';
// Import do Swagger para documentacao
import swaggerUI from 'swagger-ui-express';
import swaggerJSDoc from 'swagger-jsdoc';

configDotenv();

class App {
  constructor() {
    this.server = express();
    this.middlewares();
    this.routes();
    this.swaggerDOCS();
  }

  middlewares() {
    this.server.use(express.json());
  }

  routes() {
    this.server.use(routes);
  }

  swaggerDOCS() {
    const options = {
      definition: {
        openapi: "3.0.0",
        info: {
          title: "nova-api - API para aula do curso TDS, disciplina UC13",
          version: "1.3.2",
        },
      },
      apis: ['./src/routes.js'],
    };
    const swaggerSpec = swaggerJSDoc(options);
    this.server.use('/api-docs', swaggerUI.serve, swaggerUI.setup(swaggerSpec));
  }
}

export default new App().server;