import { Router } from 'express';
import users from './controllers/UsersController.js';
import books from './controllers/BooksController.js';
import genres from './controllers/GenresController.js';
import reservations from './controllers/ReservationsController.js';

import UserMiddleware from './middleware/UsersMiddleware.js';


const routes = new Router();

// Middleware global
routes.use((req, res, next) => {
  console.log(`Requisição recebida: ${req.method} ${req.url}`);
  next(); // Passa para o próximo middleware ou rota
});


routes.get('/', (req, res) => {
  res.json({ message: 'Welcome to the Library API! SELECT YOUR CLASS/METHOD.' });
});

// Usuários
// Listar todos os usuários
routes.get('/users', users.index);
routes.get('/users2', users.index2);
// Listar um usuário
routes.get('/users/:id', users.show);
// Criar um usuário
routes.post('/users', UserMiddleware.checkUserCreate, users.create);
// Editar um usuário
routes.put('/users/:id', users.update);
// Deletar um usuário
routes.delete('/users/:id', users.delete);

// Livros
// Listar todos os livros
routes.get('/books', books.index);
// Listar um livro
routes.get('/books/:id', books.show);
// Criar um livro
routes.post('/books', books.create);
// Editar um livro
routes.put('/books/:id', books.update);
// Deletar um livro
routes.delete('/books/:id', books.delete);

// Reservas
routes.get('/reservations', reservations.index);
routes.get('/reservations/:id', reservations.show);
routes.post('/reservations', reservations.create);
routes.put('/reservations/:id', reservations.update);
routes.delete('/reservations/:id', reservations.delete);

// Generos
routes.get('/genres', genres.index);
routes.get('/genres/:id', genres.show);
routes.post('/genres', genres.create);
routes.put('/genres/:id', genres.update);
routes.delete('/genres/:id', genres.delete);

export default routes;

/**
 * @swagger
 * /users:
 *   get:
 *     summary: Lista todos os usuarios sem possibilidade filtro
 *     tags: [Users]
 *     responses:
 *       200:
 *         description: Lista os usuários
 *         content:
 *           application/json:
 *             schema:
 *               properties:
 *                 name:
 *                   type: string
 *                 email:
 *                   type: string
 *                 phone:
 *                   type: integer
 *                 birthday:
 *                   type: string
 *                 nationality:
 *                   type: string
 *                 isAdmin:
 *                   type: boolean
 *                 isAuthor:
 *                   type: boolean
 *                 status:
 *                   type: string
 *                 password:
 *                   type: string
 *       400:
 *         description: User não encotrado
 *       500:
 *         description: Erro ao executar o procedimento
 */
/**
 * @swagger
 * /users:
 *   post:
 *     summary: Cria um novo usuário
 *     tags: [Users]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             properties:
 *               name:
 *                 type: string
 *               email:
 *                 type: string
 *               phone:
 *                 type: integer
 *               birthday:
 *                 type: date
 *               nationality:
 *                 type: string
 *               isAdmin:
 *                 type: boolean
 *               isAuthor:
 *                 type: boolean
 *               status:
 *                 type: string
 *               password:
 *                 type: string
 *     responses:
 *       201:
 *         description: Usuário criado com sucesso
 */
/**
 * @swagger
 * /genres:
 *   get:
 *     summary: Lista todos os gêneros com filtros na URI. http://servidor:3500/genres?name=Fi%
 *     tags: [Genres]
 *     responses:
 *       200:
 *         description: Lista os gêneros
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   id:
 *                     type: integer
 *                     example: 1
 *                   name:
 *                     type: string
 *                     example: "Humor"
 *       400:
 *         description: Genero não encotrado
 *       500:
 *         description: Erro ao executar o procedimento
 */