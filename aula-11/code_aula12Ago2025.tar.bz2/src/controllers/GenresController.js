// Dando erro no processo de import pois faltou
// a extensão do arquivo
import Genres from '../models/GenreModel.js';

class GenresController {
    async index (req, res) {
    }

    async show (req, res) {
    }

    async create (req, res) {
        try{
            const registrosGeneros = await Genres.create(req.body);
            if(!registrosGeneros){
                return res.status(404).json({error: 'Genre not created'});
            }
            return res.status(201).json(registrosGeneros);
        } catch(err){
            console.log('Erro: POST :: GENRES.create',err);
            return res.status(500).json({error: 'Falha ao executar o processo.'})
        }
    }

    async update (req, res) {
    }

    async delete (req, res) {
    }
}

export default new GenresController();