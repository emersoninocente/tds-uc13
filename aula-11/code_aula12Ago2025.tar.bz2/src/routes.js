import { Router } from 'express';
import users from './controllers/UsersController.js';
import books from './controllers/BooksController.js';
import genres from './controllers/GenresController.js';
import reservations from './controllers/ReservationsController.js';


const routes = new Router();

routes.get('/', (req, res) => {
  res.json({ message: 'Welcome to the Library API! SELECT YOUR CLASS/METHOD.' });
});

// Usuários
// Listar todos os usuários
routes.get('/users', users.index);
// Listar um usuário
routes.get('/users/:id', users.show);
// Criar um usuário
routes.post('/users', users.create);
// Editar um usuário
routes.put('/users/:id', users.update);
// Deletar um usuário
routes.delete('/users/:id', users.delete);

// Livros
// Listar todos os livros
routes.get('/books', books.index);
// Listar um livro
routes.get('/books/:id', books.show);
// Criar um livro
routes.post('/books', books.create);
// Editar um livro
routes.put('/books/:id', books.update);
// Deletar um livro
routes.delete('/books/:id', books.delete);

// Reservas
routes.get('/reservations', reservations.index);
routes.get('/reservations/:id', reservations.show);
routes.post('/reservations', reservations.create);
routes.put('/reservations/:id', reservations.update);
routes.delete('/reservations/:id', reservations.delete);

// Generos
routes.get('/genres', genres.index);
routes.get('/genres/:id', genres.show);
routes.post('/genres', genres.create);
routes.put('/genres/:id', genres.update);
routes.delete('/genres/:id', genres.delete);

export default routes;