// ./src/routes/UsersRoute.js
import { Router } from 'express';
import UserMiddleware from '../middleware/UsersMiddleware.js';
import token from '../middleware/VerifyTokenMiddlare.js';
import users from '../controllers/UsersController.js';

const routes = new Router();

// Usuários
// Listar todos os usuários
routes.get('/', token.verifyToken, users.index);
// Listar um usuário
routes.get('/:id', token.verifyToken, users.show);
// Criar um usuário
routes.post('/', token.verifyToken, token.verifyAdmin, UserMiddleware.checkUserCreate, users.create);
// Editar um usuário
routes.put('/:id', token.verifyToken, token.verifyAdmin, users.update);
// Deletar um usuário
routes.delete('/:id', token.verifyToken, token.verifyAdmin, users.delete);

routes.post('/login', users.login);

export default routes;