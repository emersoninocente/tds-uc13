import reservations from '../controllers/ReservationsController.js';
import { Router } from 'express';
import token from '../middleware/VerifyTokenMiddlare.js';

const routes = new Router();

// Reservas
routes.get('/', token.verifyToken, reservations.index);
routes.get('/:id', token.verifyToken, reservations.show);
routes.post('/', token.verifyToken, token.verifyAdmin, reservations.create);
routes.put('/:id', token.verifyToken, token.verifyAdmin, reservations.update);
routes.delete('/:id', token.verifyToken, token.verifyAdmin, reservations.delete);

export default routes;