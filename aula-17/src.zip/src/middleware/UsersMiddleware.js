// ./src/middleware/UsersMiddleware.js
class UserMiddleware {
    static checkUserCreate(req, res, next) {
        const { name, email, password } = req.body;
        if (!name || name.length < 5) {
            return res.status(400).json({ message: 'Param name not found' })
        };
        if (!email || !email.includes('@')) {
            return res.status(400).json({ message: 'Param email not found' })
        };
        if (!password || password.length < 8) {
            return res.status(400).json({ message: 'Param password not found' })
        };
        next();
    }
}

export default UserMiddleware;