// ./src/middleware/VerifyTokenMiddleware.js
import jwt from 'jsonwebtoken';

class VerifyTokenMiddleware {
    static verifyToken(req, res, next) {
        console.log("Alerta: Middleware verifyToken");
        const authToken = req.headers['authorization'];
        if (!authToken) {
            return res.status(401).json({ message: 'Token not provided' });
        }
        const token = authToken.split(' ')[1];
        try {
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            req.userId = decoded.id;
            req.isAdmin = decoded.isAdmin || false;
            console.log(`Token verified for user ID: ${req.userId} ${req.isAdmin}`);
            next();
        } catch (err) {
            console.log('Erro: Middleware verifyToken', err);
            return res.status(401).json({ message: 'Invalid token' });
        }
    }

    static verifyAdmin(req, res, next) {
        if (!req.isAdmin) {
            return res.status(403).json({ message: 'Admin access required' });
        }
        next();
    }
}

export default VerifyTokenMiddleware;