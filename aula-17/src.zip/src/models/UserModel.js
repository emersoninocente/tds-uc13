// ./src/models/UserModel.js
import Sequelize, { Model } from "sequelize";

class UserModel extends Model {
  checkPassword(password) {
    if(password === this.password && this.status === 1) {
      return true;
    }
    return false;
  }

  static init(sequelize) {
    super.init({
        name: {
          type: Sequelize.STRING,
          allowNull: false
        },
        email: {
          type: Sequelize.STRING,
          allowNull: false,
          unique: true,
          key: true
        },
        phone: {
          type: Sequelize.INTEGER,
          allowNull: false
        },
        birthday: {
          type: Sequelize.DATE,
          allowNull: true
        },
        nationality: {
          type: Sequelize.STRING,
          allowNull: true
        },
        isAdmin: {
          type: Sequelize.BOOLEAN,
          allowNull: false,
          defaultValue: false
        },
        isAuthor: {
          type: Sequelize.BOOLEAN,
          allowNull: false,
          defaultValue: false
        },
        status: {
          type: Sequelize.ENUM('active', 'inactive', 'banned'),
          allowNull: false,
          defaultValue: 'active'
        },
        password: {
          type: Sequelize.STRING,
          allowNull: false
        },
      }, {
        sequelize,
        tableName: 'users',
        timestamps: false
      });
  }
  
  static associate(models) {
    this.hasMany(models.ReservationModel, { foreignKey: 'userId', as: 'reservations' });
    this.hasMany(models.BookModel, { foreignKey: 'authorId', as: 'books' });
  }
}

export default UserModel;