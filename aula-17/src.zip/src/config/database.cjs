require('dotenv').config();
'use strict';

module.exports = {
  "username": process.env.USERNAMEDB,
  "password": process.env.PASSWORDDB,
  "database": process.env.NAMEDB,
  "host": process.env.HOSTDB,
  "port": process.env.PORTDB,
  "dialect": process.env.DIALECTDB,
  "dialectOptions": {allowPublicKeyRetrieval: true},
  define: {
    "timestamp": false,
    "underscored": false,
    "underscoredAll": false
  }
}