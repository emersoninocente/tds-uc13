// jest.config.cjs
module.exports = {
  testEnvironment: "node",

  // Transpila todo .js via babel-jest
  transform: {
    "^.+\\.js$": "babel-jest"
  },

  // Extensões que o Jest vai resolver
  moduleFileExtensions: ["js", "cjs", "json", "node"],

  // Usa arquivo de setup escrito em CJS
  //setupFilesAfterEnv: ["./jest.setup.cjs"],

  // Encontra somente .cjs dentro de tests/
  testMatch: ["**/tests/**/*.cjs"]
};
