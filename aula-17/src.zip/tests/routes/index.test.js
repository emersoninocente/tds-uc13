import request from 'supertest';
import app from '../../src/app.js';

describe('GET /', () => {
  it('mensagem de boas-vindas', async () => {
    const res = await request(app).get('/');
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty('message');
  });
});