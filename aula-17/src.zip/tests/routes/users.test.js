import request from 'supertest';
import app from '../../src/app.js';

jest.mock('../../src/middleware/VerifyTokenMiddleware.js', () => ({
  verifyToken: (req,res,next)=>next(),
  verifyAdmin: (req,res,next)=>next()
}));
jest.mock('../../src/middleware/UsersMiddleware.js', () => ({
  checkUserCreate:(req,res,next)=>next()
}));

describe('Rotas /users', () => {
  it('GET /users existe', async () => {
    const res = await request(app).get('/users');
    expect(res.status).not.toBe(404);
  });

  it('POST /users cria usuário', async () => {
    const payload = { name:'Teste', email:'test@testdomain.com', password:'12345678' };
    const res = await request(app).post('/users').send(payload);
    expect([200,201,400,401]).toContain(res.status);
  });
});