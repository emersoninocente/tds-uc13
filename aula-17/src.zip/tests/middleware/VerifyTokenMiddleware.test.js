import jwt from 'jsonwebtoken';
import VerifyTokenMiddleware from '../../src/middleware/VerifyTokenMiddlare.js';
import { mockRes, mockNext } from '../utils/mockResponse.js';

jest.mock('jsonwebtoken');

describe('VerifyTokenMiddleware.verifyToken', () => {
  it('rejeita sem token', () => {
    const req = { headers:{} };
    const res = mockRes();
    const next = mockNext();

    VerifyTokenMiddleware.verifyToken(req, res, next);
    expect(res.status).toHaveBeenCalledWith(401);
    expect(res.json).toHaveBeenCalledWith({ message:'Token not provided' });
  });

  it('rejeita token inválido', () => {
    const req = { headers:{ authorization:'Bearer bad'} };
    jwt.verify.mockImplementation(() => { throw new Error(); });
    const res = mockRes();
    const next = mockNext();

    VerifyTokenMiddleware.verifyToken(req, res, next);
    expect(res.status).toHaveBeenCalledWith(401);
    expect(res.json).toHaveBeenCalledWith({ message:'Invalid token' });
  });

  it('aceita token válido', () => {
    const req = { headers:{ authorization:'Bearer ok'} };
    jwt.verify.mockReturnValue({ id:42, isAdmin:true });
    const res = mockRes();
    const next = mockNext();

    VerifyTokenMiddleware.verifyToken(req, res, next);
    expect(req.userId).toBe(42);
    expect(req.isAdmin).toBe(true);
    expect(next).toHaveBeenCalled();
  });
});

describe('VerifyTokenMiddleware.verifyAdmin', () => {
  it('rejeita não-admin', () => {
    const req = { isAdmin:false };
    const res = mockRes();
    const next = mockNext();

    VerifyTokenMiddleware.verifyAdmin(req, res, next);
    expect(res.status).toHaveBeenCalledWith(403);
    expect(res.json).toHaveBeenCalledWith({ message:'Admin access required' });
  });

  it('aceita admin', () => {
    const req = { isAdmin:true };
    const res = mockRes();
    const next = mockNext();

    VerifyTokenMiddleware.verifyAdmin(req, res, next);
    expect(next).toHaveBeenCalled();
  });
});