import UserMiddleware from '../../src/middleware/UsersMiddleware.js';
import { mockRes, mockNext } from '../utils/mockResponse.js';

describe('UserMiddleware.checkUserCreate', () => {
  it('permite payload válido', () => {
    const req = { body: { name:'Aluno Teste', email:'a@b.com', password:'12345678' } };
    const res = mockRes();
    const next = mockNext();

    UserMiddleware.checkUserCreate(req, res, next);
    expect(next).toHaveBeenCalled();
  });

  it('rejeita nome curto', () => {
    const req = { body: { name:'Ana', email:'a@b.com', password:'12345678' } };
    const res = mockRes();
    const next = mockNext();

    UserMiddleware.checkUserCreate(req, res, next);
    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith({ message:'Param name not found' });
  });

  // Cenários: email inválido, senha curta
});