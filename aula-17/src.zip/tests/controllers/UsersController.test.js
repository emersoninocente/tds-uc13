import UsersController from '../../src/controllers/UsersController.js';
import User from '../../src/models/UserModel.js';
import { mockRes, mockNext } from '../utils/mockResponse.js';

jest.mock('../../src/models/UserModel.js');

describe('UsersController.login', () => {
  const mockRes = () => {
    const res = {};
    res.status = jest.fn().mockReturnValue(res);
    res.json = jest.fn().mockReturnValue(res);
    return res;
  };

  it('deve autenticar com credenciais válidas', async () => {
    const req = { body: { email: 'test@example.com', password: '12345678' } };
    const res = mockRes();

    User.findOne.mockResolvedValue({
      id: 1,
      email: 'test@example.com',
      isAdmin: true,
      checkPassword: jest.fn().mockResolvedValue(true)
    });

    await UsersController.login(req, res);
    expect(res.status).not.toHaveBeenCalledWith(401);
    expect(res.json).toHaveBeenCalledWith(expect.objectContaining({ token: expect.any(String) }));
  });

  it('deve falhar com credenciais inválidas', async () => {
    const req = { body: { email: 'test@example.com', password: 'wrong' } };
    const res = mockRes();

    User.findOne.mockResolvedValue({
      checkPassword: jest.fn().mockResolvedValue(false)
    });

    await UsersController.login(req, res);
    expect(res.status).toHaveBeenCalledWith(401);
    expect(res.json).toHaveBeenCalledWith({ error: 'Invalid email or password' });
  });
});

describe('UsersController.index', () => {
  it('deve retornar lista de usuários', async () => {
    const req = { query: {} };
    const res = mockRes();

    User.findAll.mockResolvedValue([{ id: 1, name: 'Emerson' }]);

    await UsersController.index(req, res);
    expect(res.json).toHaveBeenCalledWith(expect.any(Array));
  });

  it('deve retornar 404 se nenhum usuário encontrado', async () => {
    const req = { query: {} };
    const res = mockRes();

    User.findAll.mockResolvedValue([]);

    await UsersController.index(req, res);
    expect(res.status).toHaveBeenCalledWith(404);
    expect(res.json).toHaveBeenCalledWith({ error: 'No users found' });
  });
});

describe('UsersController.show', () => {
  it('deve retornar dados do usuário', async () => {
    const req = { params: { id: 1 } };
    const res = mockRes();

    User.findOne.mockResolvedValue({ name: 'Emerson' });

    await UsersController.show(req, res);
    expect(res.json).toHaveBeenCalledWith({ name: 'Emerson' });
  });

  it('deve retornar 404 se usuário não existir', async () => {
    const req = { params: { id: 999 } };
    const res = mockRes();

    User.findOne.mockResolvedValue(null);

    await UsersController.show(req, res);
    expect(res.status).toHaveBeenCalledWith(404);
    expect(res.json).toHaveBeenCalledWith({ error: 'User not found' });
  });
});

describe('UsersController.create', () => {
  it('deve criar usuário com sucesso', async () => {
    const req = { body: { name: 'Novo Usuário' } };
    const res = mockRes();

    User.create.mockResolvedValue({ id: 1, name: 'Novo Usuário' });

    await UsersController.create(req, res);
    expect(res.status).toHaveBeenCalledWith(201);
    expect(res.json).toHaveBeenCalledWith({ id: 1, name: 'Novo Usuário' });
  });
});

describe('UsersController.update', () => {
  it('deve atualizar usuário existente', async () => {
    const req = { params: { id: 1 }, body: { name: 'Atualizado' } };
    const res = mockRes();

    User.update.mockResolvedValue([1]);
    User.findOne.mockResolvedValue({ id: 1, name: 'Atualizado' });

    await UsersController.update(req, res);
    expect(res.json).toHaveBeenCalledWith({ id: 1, name: 'Atualizado' });
  });

  it('deve retornar 404 se usuário não for atualizado', async () => {
    const req = { params: { id: 999 }, body: {} };
    const res = mockRes();

    User.update.mockResolvedValue([0]);

    await UsersController.update(req, res);
    expect(res.status).toHaveBeenCalledWith(404);
    expect(res.json).toHaveBeenCalledWith({ error: 'User not found' });
  });
});

describe('UsersController.delete', () => {
  it('deve deletar usuário existente', async () => {
    const req = { params: { id: 1 } };
    const res = mockRes();

    User.destroy.mockResolvedValue(1);

    await UsersController.delete(req, res);
    expect(res.status).toHaveBeenCalledWith(204);
    expect(res.send).toHaveBeenCalled();
  });

  it('deve retornar 404 se usuário não existir', async () => {
    const req = { params: { id: 999 } };
    const res = mockRes();

    User.destroy.mockResolvedValue(0);

    await UsersController.delete(req, res);
    expect(res.status).toHaveBeenCalledWith(404);
    expect(res.json).toHaveBeenCalledWith({ error: 'User not found' });
  });
});