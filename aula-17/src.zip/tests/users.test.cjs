// tests/users.test.cjs
const request = require("supertest");
const app = require("../src/app.js").default;       // .default porque é exportação ESM
const User = require("../src/models/UserModel.js").default;
const sequelize = require("../src/database/index.js").default;

describe("Rota de Usuários", () => {
  let adminToken;

//  beforeAll(async () => {
//    await sequelize.sync({ force: true });
//    await User.create({
//      name: "Admin Tester",
//      email: "admin@test.com",
//      phone: "5199987",
//      password: "password123",
//      isAdmin: true
//    });
//  });
//
//  afterAll(async () => {
//    await sequelize.close();
//  });

  it("faz login e retorna token", async () => {
    const res = await request(app)
      .post("/users/login")
      .send({ email: "admin@dominio.com.br", password: "minhasenhaforte" });

    expect(res.status).toBe(200);
    expect(res.body.token).toBeDefined();
    adminToken = res.body.token;
  });

  it("falha em acessar sem token", async () => {
    const res = await request(app).get("/users/");
    expect(res.status).toBe(401);
  });

  it("lista usuários com token de admin", async () => {
    const res = await request(app)
      .get("/users/")
      .set("Authorization", `Bearer ${adminToken}`);

    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });

  it("cria usuário com validação de campos", async () => {
    const newUser = {
      name: "User Test",
      email: "user2@test.com",
      phone: 51999888,
      password: "mypassword",
      status: 1
    };
    const res = await request(app)
      .post("/users/")
      .set("Authorization", `Bearer ${adminToken}`)
      .send(newUser);

    expect(res.status).toBe(201);
    expect(res.body.email).toBe(newUser.email);
  });

  it("retorna 400 ao criar usuário inválido", async () => {
    const res = await request(app)
      .post("/users/")
      .set("Authorization", `Bearer ${adminToken}`)
      .send({ name: "A", email: "bademail", password: "123" });

    expect(res.status).toBe(400);
  });
});