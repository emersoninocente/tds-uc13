// tests/setup/sequelizeTestSetup.js
import { Sequelize } from 'sequelize';
import UserModel from '../../src/models/UserModel.js';

export const sequelize = new Sequelize('sqlite::memory:', {
  logging: false,
});

export const initModels = () => {
  UserModel.init(sequelize);
  // Se tiver associações, chame aqui também
  // UserModel.associate({ ... });
};

export const syncDatabase = async () => {
  await sequelize.sync({ force: true });
};