import request from 'supertest';
import { expect } from 'chai';
import app from '../../src/app.js';
import SequelizeMock from 'sequelize-mock';

// Mock Sequelize database
const DBConnectionMock = new SequelizeMock();
const UserMock = DBConnectionMock.define('User', {
  id: 1,
  name: 'John Doe',
  email: 'john@example.com',
});

// Mock the Sequelize model
import User from '../../src/models/UserModel.js';
User.findAll = UserMock.findAll;

describe('GET /users', () => {
  it('should return all users', async () => {
    const response = await request(app).get('/users');

    expect(response.status).to.equal(200);
    expect(response.body).to.be.an('array');
    expect(response.body[0]).to.have.property('name', 'John Doe');
  });
});