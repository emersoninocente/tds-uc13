import { expect } from 'chai';
import sinon from 'sinon';
import { Op } from 'sequelize';
import UsersController from '../../src/controllers/UsersController.js';
import User from '../../src/models/UserModel.js';
import dotenv from 'dotenv';
dotenv.config({path: '.env.test'});

describe('Unitário - UsersController', () => {
  afterEach(() => sinon.restore());

  it('Login - Deve retornar 200 com token válido', async () => {
    const req = {
      body: { email: 'teste@exemplo.com', password: 'senha1234' }
    };

    const res = {
      status: sinon.stub().returnsThis(),
      json: sinon.stub()
    };

    const fakeUser = {
      id: 1,
      email: req.body.email,
      isAdmin: false,
      status: 1,
      password: req.body.password,
      checkPassword: sinon.stub().resolves(true)
    };

    sinon.stub(User, 'findOne').resolves(fakeUser);

    await UsersController.login(req, res);

    expect(res.status.calledWith(200)).to.be.true;
    expect(res.json.firstCall.args[0]).to.have.property('token');
  });

  it('Login - Deve retornar 401 com senha inválida', async () => {
    const req = {
        body: { email: 'teste@exemplo.com', password: 'errada' }
    };
    const res = {
        status: sinon.stub().returnsThis(),
        json: sinon.stub()
    };

    const fakeUser = {
        checkPassword: sinon.stub().resolves(false)
    };

    sinon.stub(User, 'findOne').resolves(fakeUser);

    await UsersController.login(req, res);

    expect(res.status.calledWith(401)).to.be.true;
  });

    it('Login - Deve retornar 401 com email não encontrado', async () => {
        const req = {
            body: { email: 'teste@exemplo.com', password: 'senha1234' }
        };
        const res = {
            status: sinon.stub().returnsThis(),
            json: sinon.stub()
        };
        sinon.stub(User, 'findOne').resolves(null);
        await UsersController.login(req, res);
        expect(res.status.calledWith(401)).to.be.true;
    });

    it('Login - Deve retornar 500 em caso de erro no servidor', async () => {
        const req = {
            body: { email: 'teste@exemplo.com', password: 'senha1234' }
        };
        const res = {
            status: sinon.stub().returnsThis(),
            json: sinon.stub()
        };
        sinon.stub(User, 'findOne').throws(new Error('DB error'));
        await UsersController.login(req, res);
        expect(res.status.calledWith(500)).to.be.true;
    });

    it('User Index - Deve retornar 200, lista de usuários sem filtros', async () => {
        const req = { query: {} };
        const res = {
            status: sinon.stub().returnsThis(),
            json: sinon.stub()
        };
        const fakeUsers = [
            { id: 1, name: 'Teste 01', email: 'teste@teste.com.br', phone: 51999999, birthday: '2010-08-27', nationality: 'Brasileiro', isAdmin: true, isAuthor: false, status: 1 },
            { id: 2, name: 'Teste 02', email: 'teste2@teste.com.br', phone: 51999998, birthday: '1995-08-27', nationality: 'Brasileiro', isAdmin: false, isAuthor: true, status: 1 }
        ];
        sinon.stub(User, 'findAll').resolves(fakeUsers);
        await UsersController.index(req, res);

        expect(res.status.calledWith(200)).to.be.true;
        expect(res.json.firstCall.args[0]).to.deep.equal(fakeUsers);
    });

    it('Deve retornar 200 e lista de usuários filtrados por nome', async () => {
    const req = { query: { name: 'Jo%' } };
    const res = {
      status: sinon.stub().returnsThis(),
      json: sinon.stub()
    };

    const fakeUsers = [
      { id: 1, name: 'Teste 01', email: 'teste@teste.com.br', phone: 51999999, birthday: '2010-08-27', nationality: 'Brasileiro', isAdmin: true, isAuthor: false, status: 1 },
      { id: 2, name: 'Teste 02', email: 'teste2@teste.com.br', phone: 51999998, birthday: '1995-08-27', nationality: 'Brasileiro', isAdmin: false, isAuthor: true, status: 1 },
      { id: 3, name: 'João Galinha', email: 'joao.galinha@teste.com.br', phone: 51999999, birthday: '2010-08-27', nationality: 'Brasileiro', isAdmin: false, isAuthor: true,  status: 1 }
    ];

    const findAllStub = sinon.stub(User, 'findAll').resolves(fakeUsers);

    await UsersController.index(req, res);

    // Verifica se o método foi chamado com os filtros corretos
    expect(findAllStub.calledOnce).to.be.true;
    const queryArgs = findAllStub.firstCall.args[0];
    expect(queryArgs).to.have.property('where');
    expect(queryArgs.where).to.have.property('name');
    expect(queryArgs.where.name).to.have.property(Op.like, 'Jo%');
    //console.log('Depuração: Argumentos da consulta:', queryArgs);

    // Verifica resposta
    expect(res.status.calledWith(200)).to.be.true;
    expect(res.json.calledOnce).to.be.true;
    //expect(res.json.firstCall.args[0]).to.be.an('array').with.lengthOf(1);
    //expect(res.json.firstCall.args[0][0]).to.have.property('name', 'João Galinha');
    expect(res.json.firstCall.args[0]).to.be.an('array');
  });
  
});