import { Router } from 'express';
import genres from '../controllers/GenresController.js';
import token from '../middleware/VerifyTokenMiddleware.js';

const routes = new Router();

// Generos
routes.get('/', token.verifyToken, genres.index);
routes.get('/:id', token.verifyToken, genres.show);
routes.post('/', token.verifyToken, token.verifyAdmin, genres.create);
routes.put('/:id', token.verifyToken, token.verifyAdmin, genres.update);
routes.delete('/:id',token.verifyToken, token.verifyAdmin, genres.delete);

export default routes;