import { Router } from 'express';
import books from '../controllers/BooksController.js';
import token from '../middleware/VerifyTokenMiddleware.js';

const routes = new Router();

// Livros
// Listar todos os livros
routes.get('/', token.verifyToken, books.index);
// Listar um livro
routes.get('/:id', token.verifyToken, books.show);
// Criar um livro
routes.post('/', token.verifyToken, token.verifyAdmin, books.create);
// Editar um livro
routes.put('/:id', token.verifyToken, token.verifyAdmin, books.update);
// Deletar um livro
routes.delete('/:id', token.verifyToken, token.verifyAdmin, books.delete);

export default routes;