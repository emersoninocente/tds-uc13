require('dotenv').config();

const config = {
  development: {
    "username": process.env.USERNAMEDB,
    "password": process.env.PASSWORDDB,
    "database": process.env.NAMEDB,
    "host": process.env.HOSTDB,
    "port": process.env.PORTDB,
    "dialect": process.env.DIALECTDB,
    "dialectOptions": {allowPublicKeyRetrieval: true},
    define: {
      "timestamp": false,
      "underscored": false,
      "underscoredAll": false
    }
  },
  test: {
    dialect: 'sqlite',
    storage: ':memory:', // Indica que o banco de dados rodará em memória RAM
    logging: false, // Desativa os logs de SQL no console durante os testes
    define: {
      timestamp: false,
      underscored: false,
      underscoredAll: false
    }
  }
};

module.exports = config[process.env.NODE_ENV || 'development'];