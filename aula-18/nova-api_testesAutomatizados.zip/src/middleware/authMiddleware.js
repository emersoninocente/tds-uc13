// middleware/authMiddleware.js
module.exports = (req, res, next) => {
  next();
};